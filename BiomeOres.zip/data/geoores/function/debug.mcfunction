tellraw @s {"text":"GeoOres v4 loaded","color":"green"}
tellraw @s {"text":"Zones: highland / temperate / humid / arid / cold","color":"aqua"}
tellraw @s {"text":"Vanilla ore gen replaced. New chunks only!","color":"yellow"}
